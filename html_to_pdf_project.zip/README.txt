
# HTML to PDF Generator

## 🧾 Description
This project converts an HTML file with inline CSS into a styled PDF using Python and pdfkit.

## 📦 Requirements
- Python 3.x
- pdfkit
- wkhtmltopdf (Must be installed separately)

## ⚙️ Installation Steps

### 1. Install Python packages:
```bash
pip install -r requirements.txt
```

### 2. Install wkhtmltopdf

- Windows: Download from https://wkhtmltopdf.org/downloads.html (add to PATH)
- Ubuntu:
```bash
sudo apt install wkhtmltopdf
```
- MacOS:
```bash
brew install --cask wkhtmltopdf
```

### 3. Run the script
```bash
python generate_pdf.py
```

The output PDF will be saved as `sample_output.pdf`.

## 📁 Files Included
- `sample.html` — HTML template with inline CSS.
- `generate_pdf.py` — Python script to generate PDF.
- `requirements.txt` — Python dependencies.
