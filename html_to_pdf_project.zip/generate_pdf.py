
import pdfkit
import os

def generate_pdf_from_html(html_path: str, output_path: str = "output.pdf"):
    """
    Converts an HTML file with inline CSS to a PDF.

    Parameters:
    html_path (str): Path to the input HTML file.
    output_path (str): Desired output PDF file path.

    Returns:
    str: Output path of the generated PDF.
    """
    if not os.path.exists(html_path):
        raise FileNotFoundError(f"HTML file not found: {html_path}")

    try:
        pdfkit.from_file(html_path, output_path)
        print(f"✅ PDF generated successfully: {output_path}")
        return output_path
    except Exception as e:
        print(f"❌ Error generating PDF: {e}")
        return None

# Example usage
if __name__ == "__main__":
    generate_pdf_from_html("sample.html", "sample_output.pdf")
